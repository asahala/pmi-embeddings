#!/bin/bash
#SBATCH --job-name=myTest
#SBATCH --account=[ADD PROJECT ID]
#SBATCH --cpus-per-task=2
#SBATCH --gres=gpu:v100:1
#SBATCH --time=10:00:00
#SBATCH --mem=8G
#SBATCH --partition=gpu
module load python-data
python3 train_fasttext.py
