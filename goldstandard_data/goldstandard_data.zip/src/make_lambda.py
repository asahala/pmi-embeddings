import compute_svd_ppmi_lambda_vectors as CL

def compute_lambda_vectors(corpus_file, chunk_size=3000000, min_count=1,
                           subsampling_rate=0, smoothing_factor=0.0001,
                           threshold=0, window_size=5, verbose=True):

    word_vector_filename = 'lambda.vec'
    m, word_to_id = CL.file_to_cooc_matrix(corpus_file,
                                        chunk_size,
                                        window_size,
                                        min_count,
                                        subsampling_rate,
                                        verbose)
    vocab = list(word_to_id.keys())
    m = CL.pmi_weight(m, smoothing_factor,
                   threshold, verbose)

    print('SVD')
    m, _, _ = CL.randomized_svd(m, n_components=100, random_state=0)
    
    m = CL.normalize(m, norm='l2', axis=1, copy=False)

    CL.save_word_vectors(word_vector_filename, m, word_to_id, vocab,
                          verbose=verbose)

    lens = set()
    with open('lambda.vec', 'r', encoding='utf-8') as f:
        for line in f.read().splitlines():
            lens.add(len(line.split(' ')))

    print(lens)
#compute_lambda_vectors('enwiki1M/enwik9-2M-010.txt')
