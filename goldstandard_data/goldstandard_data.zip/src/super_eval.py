import make_embeddings as ME
import sys
import os
import math
from collections import defaultdict
from gensim.models import KeyedVectors, Word2Vec, FastText
import make_lambda as ML

parameters = {'window_size': 5,
                  'min_count': 1,
                  'subsampling_rate': None,
                  'k_factor': 1,
                  'dirty_stopwords': False,
                  'dynamic_window': False}

pmi_parameters = {'shift_type': 0,
                      'alpha': 0.75,
                      'lambda_': 0.0001,
                      'threshold': 5}

dimensions = 100

w2v_parameters = {'window': 1,
                  'min_count':1,
                  'epochs': 5}

w2v_dimensions = 100

testpath = 'enwiki1M'
prefix = 'enwiki-1M-'
corpora = [os.path.join(testpath,x) for x in os.listdir(testpath) if x.startswith(prefix) and x.endswith('.txt')]
#corpora = ['enwiki1M/enwiki-1M-0.txt']
#corpora = ['akkadian-all-mini.wpl']#['akk_smallset.wpl']#full-0.wpl', 'akk-full-1.wpl', 'akk-full-2.wpl']#['akk_smallset.wpl']#['akkadian-all-mini.wpl']#enwiki-2M-lem.txt']
#corpora = ['akkadian-all-mini.wpl']
#corpora = ['akk-small-stop.txt']
#corpora = ['akk_smallset.wpl']
#corpora = ['enwiki/enwik9_tail_2M.txt']
#corpora = ['lacuna/akkadian-all-mini-lac1.wpl']
golds = {'men    ': ['men.tab'],
         'wordsim': ['wordsim353.tab'],
         'simlex ': ['simlex999.tab'],
         'rarewrd': ['rw.tab'],
         'rg-65  ': ['rg-65.tab']}


vectorname = 'temporary.vec'
prefix = 'subsampling-'

"""

goldpath = 'diff'
gp2 = os.path.join('diff', 'groups')
golds = {'diff1': ['diff/gold-diff1.tsv'],
         'diff2': [os.path.join(goldpath,x) for x in os.listdir(goldpath) if x.startswith('diff2-')],
         'diff3': [os.path.join(goldpath,x) for x in os.listdir(goldpath) if x.startswith('diff3-')],
         'diff4': [os.path.join(goldpath,x) for x in os.listdir(goldpath) if x.startswith('diff4-')],
         'diffmax': ['diff/gold-diffmax.tsv'],
         'd123': [os.path.join(gp2,x) for x in os.listdir(gp2) if x.startswith('gold-diff-123-')],
         'd456': [os.path.join(gp2,x) for x in os.listdir(gp2) if x.startswith('gold-diff-456-')],
         'd789': [os.path.join(gp2,x) for x in os.listdir(gp2) if x.startswith('gold-diff-789-')],
         #'diff not 2': ['diff/gold-diff-not-2.tsv'],
         'boot-100': [x for x in os.listdir() if x.startswith('boot_')],
         'boot-50': [os.path.join('bootstrap', x) for x in os.listdir('bootstrap')],
         'gold-full': ['gold_updated.tsv']}

gp2 = 'parts'
golds = {'R1':[os.path.join(gp2,x) for x in os.listdir(gp2) if x.startswith('gold-JT-')],
         'R2':[os.path.join(gp2,x) for x in os.listdir(gp2) if x.startswith('gold-JN-')],
         'R3':[os.path.join(gp2,x) for x in os.listdir(gp2) if x.startswith('gold-GL-')],
         'R4':[os.path.join(gp2,x) for x in os.listdir(gp2) if x.startswith('gold-PT-')],
         'R5':[os.path.join(gp2,x) for x in os.listdir(gp2) if x.startswith('gold-BB-')]}
"""

def make_pmi_id(par, pmi_par, dim):
    pars = ' '.join([f'{x[0:3]}={y}' for x, y in par.items()]) + ' ' +\
           ' '.join([f'{x[0:3]}={y}' for x, y in pmi_par.items()]) + ' ' +\
                           f'dim={dim}'
    return f'pmi :: {pars}'

def make_sgns_id(w2v_params, dim):
    pars = ' '.join([f'{x[0:3]}={y}' for x, y in w2v_params.items()]) + ' ' +\
        f'dim={dim}'
    return f'sgns :: {pars}'

def _average(array):
    if not array:
        return '-'
    return round(sum(array) / len(array), 3)

def _conf_interval(array):
    """ Calculate confidence interval

    :param n          number of samples
    :param acc        list of results

    :type n           int
    :type acc         [float, ...]  """

    n = len(array.tolist())

    avg = sum(array) / len(array)
    dev = ((x - avg)**2 for x in array)
    var = sum(dev) / max((n-1), 1)
    std_dev = math.sqrt(var)

    return round(1.96 * (std_dev / math.sqrt(n)), 2)

def _make_texts(corpus):
    """ Prepares WPL file for Word2vec model input """
    texts = []
    with open(corpus, 'r', encoding='utf-8') as f:
        text = []
        for e, line in enumerate(f.read().splitlines()):
            text.append(line)
            if line == '#':
                texts.append(text)
                text = []
            if e % 1000 == 0:
                texts.append(text)
                text = []
        if not texts:
            texts.append(text)
            print('should not see this')
    print(len(texts))
    return texts                                                

def write_results(filename, content, identifier):
    with open(filename, 'a', encoding='utf-8') as f:
        f.write(f'## {identifier}\n')
        f.write(f'gold\tavg ρ\tmin ρ\tmax ρ\n')
        for goldset, scores in content.items():
            if scores:
                minimum = round(min(scores), 3)
                maximum = round(max(scores), 3)
            else:
                maximum = '-'
                minimum = '-'
            f.write(f'{goldset}\t{_average(scores)}\t{minimum}\t{maximum}\n')
        f.write('=================================\n')
        
def build_pmi_vectors(corpus, chunksize, params, pmi_params, dimensions):
    """ Builds vectors using PMI-embeddings """
    embeddings = ME.Cooc(corpus, chunksize, verbose=False, **params)
    embeddings.count_cooc()
    embeddings.calculate_pmi(**pmi_params)
    embeddings.factorize(dimensions)
    embeddings.save_vectors(vectorname)

def evaluate_vectors(datasets, vectorfile=None):
    #if vectorfile is not None:
    #    vectorname = vectorfile
    #else:
    #    vectorname
        
    vecs = KeyedVectors.load_word2vec_format(vectorname, binary=False)
    spearman_scores = []
    pearson_scores = []

    for dataset in datasets:
        results = vecs.evaluate_word_pairs(dataset,
                                           restrict_vocab=10000000,
                                           dummy4unknown=False)
        pearson, spearman, oov_ratio = results
        spearman_scores.append(spearman[0])
        pearson_scores.append(pearson[0])

    avg_spearman = _average(spearman_scores)
    avg_pearson = _average(pearson_scores)

    return spearman_scores


def super_eval_pmi():
    results = {k: [] for k in golds}
    tot = len(corpora)
    for e, filename in enumerate(corpora):
        sys.stdout.write(str(e))
        build_pmi_vectors(filename, 400000, parameters, pmi_parameters, dimensions)
        for name, gold_standard in golds.items():
            score = evaluate_vectors(gold_standard)
            results[name].extend(score)
            print(filename, name, _average(score))

    return results

def super_eval_sgns(retrain, window, min_count, epochs):
    i = 0
    tot = len(corpora)
    results = {k: [] for k in golds}
    while i < retrain:
        #sys.stdout.write(str(i))
        print(f'{i}/{retrain}')
        for e, filename in enumerate(corpora):
        
            texts = _make_texts(filename)
            model = Word2Vec(vector_size=w2v_dimensions, sg=1, window=window, min_count=min_count, sentences=texts, epochs=epochs, seed=i)
            model.wv.save_word2vec_format(vectorname, binary=False)
            for name, gold_standard in golds.items():
                score = evaluate_vectors(gold_standard)
                results[name].extend(score)
                print(filename, name, _average(score))
        i += 1
    return results

def eval_only(vectorfile, gold_standards):
    results = {k: [] for k in gold_standards}
    for name, gold_standard in gold_standards.items():
        score = evaluate_vectors(gold_standard, vectorfile=vectorfile)
        results[name].extend(score)
        print(score)

    return results
    

def SGNS():
    #eval_only('lambda-100.vec', golds)
    results = super_eval_sgns(retrain=10, window=w2v_parameters['window'], min_count=w2v_parameters['min_count'], epochs=w2v_parameters['epochs'])            
    id_ = make_sgns_id(w2v_parameters, w2v_dimensions)
    write_results(f'{prefix}sgns.txt', results, id_)

def PMI():
    OUTFILE = f'{prefix}pmi.txt'
    results = super_eval_pmi()
    id_ = make_pmi_id(pmi_parameters, parameters, dimensions)
    write_results(OUTFILE, results, id_)

def LAMBDA():
    results = {k: [] for k in golds}
    for corpus in corpora:
        ML.compute_lambda_vectors(corpus)
        #results = {k: [] for k in gold_standards}
        for name, gold_standard in golds.items():
            score = evaluate_vectors(gold_standard)
            results[name].extend(score)
            print(name, score)
    write_results('eval-500k-lambda.txt', results, 'lambda-vectors-default')

#LAMBDA()
#for k in [True, False]:
#    parameters['dynamic_window'] = k
PMI()
#SGNS()
