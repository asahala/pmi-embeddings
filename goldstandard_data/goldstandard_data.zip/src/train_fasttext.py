from gensim.models import Word2Vec, FastText
from gensim.models import KeyedVectors
import os

texts = []

with open('akk_smallset.wpl', 'r', encoding='utf-8') as f:
    text = []
    for line in f.read().splitlines():
        text.append(line)
        if line == '#':
            texts.append(text)
            text = []
    
#model = Word2Vec(vector_size=60, window=3, min_count=1, sentences=texts, epochs=25)

#model.wv.save_word2vec_format('fasttext.test', binary=False)

#model = KeyedVectors.load_word2vec_format('fasttext.test', encoding='utf8')

datasets = [os.path.join('parts', x) for x in os.listdir('parts') if x.startswith('gold-GL-') and x.endswith('.smp')]
#datasets = ['gold-diff1.tsv']
datasets = [os.path.join('bootstrap', x) for x in os.listdir('bootstrap')]
#datasets = ['gold_updated.tsv']
output_file = 'hypertune-fasttest-smallset-bootstrap.txt'
TESTRUN = 1
vecname = 'xft-boot.vec'

def evaluate_model(datasets, dim, epochs, window, mincount):
    """ :param datasets           list of gold standard file names 
        :param p                  current test parameters
        :param pmi_p              current PMI test parameters
        :param d                  current dimensionality """

    global TESTRUN

    vecs = KeyedVectors.load_word2vec_format(vecname, encoding='utf-8')
    spearman_scores = []
    pearson_scores = []

    """ Evaluate against all given data sets and get avg. scores """
    for dataset in datasets:
        results = vecs.evaluate_word_pairs(dataset,
                                           restrict_vocab=10000000,
                                           dummy4unknown=False)
        pearson, spearman, oov_ratio = results
        spearman_scores.append(spearman[0])
        pearson_scores.append(pearson[0])

    avg_spearman = round(sum(spearman_scores) / len(spearman_scores), 3)
    avg_pearson = round(sum(pearson_scores) / len(pearson_scores), 3)

    #by_spear[avg_spearman].append(p)
    #by_pear[avg_pearson].append(p)
    #all_ =  {**p, **pmi_p}
    #logline = '\t'.join(['%s=%s' % (k, str(v)) for k, v in sorted(all_.items())])
    logline = f'dim={dim}\tepoch={epochs}\tmincount={mincount}\twindow={window}'
    line = str(round((avg_spearman+avg_pearson)/2, 3)) + '\t' + str(avg_spearman) + '\t' + str(avg_pearson) + '\t' + logline
    print(str(TESTRUN).zfill(2) + ': ' + line[0:60] + '...')
    TESTRUN += 1

    """ Write logfile """
    with open(output_file, 'a') as f:
        f.write(line + '\n')

dimensions_ = [50, 60, 100, 120, 200, 240, 300]
windows_ = [1,2,3,4,5]
min_count_ = [1,3,5,7]
epochs_ = [5, 7, 10, 25]

for dim in dimensions_:
    for win in windows_:
        for minc in min_count_:
            for e in epochs_:
                model = FastText(vector_size=dim, sg=1, window=win, min_count=minc, sentences=texts, epochs=e, seed=1)
                model.wv.save_word2vec_format(vecname, binary=False)
                evaluate_model(datasets, dim, e, win, minc)
                
                #model = Word2Vec(vector_size=dim, sg=1, window=win, min_count=minc, sentences=texts, epochs=e, seed=1)
                #model.wv.save_word2vec_format(vecname, binary=False)
                #model = KeyedVectors.load_word2vec_format('fasttext.test', encoding='utf8')
                #evaluate_model(datasets, dim, e, win, minc)
