from gensim.models import Word2Vec, FastText
from gensim.models import KeyedVectors
import os

texts = []
# dim=120 epoch=5 mincount=1      window=1
"""
0.418   0.425   0.412   dim=120 epoch=5 mincount=1      window=1
0.418   0.425   0.41    dim=120 epoch=7 mincount=1      window=1
0.418   0.426   0.409   dim=240 epoch=7 mincount=1      window=1
0.42    0.424   0.416   dim=240 epoch=5 mincount=3      window=1
"""

FN = 'akk-test.txt'
with open(FN, 'r', encoding='utf-8') as f:
    text = []
    for line in f.read().splitlines():
        text.append(line)
        if line == '#':
            texts.append(text)
            text = []

#model = Word2Vec(vector_size=60, window=3, min_count=1, sentences=texts, epochs=25)

#model.wv.save_word2vec_format('fasttext.test', binary=False)

#model = KeyedVectors.load_word2vec_format('fasttext.test', encoding='utf8')

#datasets = [x for x in os.listdir() if x.startswith('bstrap') and x.endswith('.smp')]
#datasets = ['gold_updated.tsv']#wordsim353.tab', 'men.tab']#, 'gold-diff2.tsv']
datasets = [os.path.join('bootstrap', x) for x in os.listdir('bootstrap')]
TESTRUN = 1

overall_average = []
def evaluate_model(datasets, dim, epochs, window, mincount):
    """ :param datasets           list of gold standard file names 
        :param p                  current test parameters
        :param pmi_p              current PMI test parameters
        :param d                  current dimensionality """

    global TESTRUN

    vecs = KeyedVectors.load_word2vec_format('ft.test', encoding='utf-8')
    spearman_scores = []
    pearson_scores = []

    """ Evaluate against all given data sets and get avg. scores """
    for dataset in datasets:
        results = vecs.evaluate_word_pairs(dataset,
                                           restrict_vocab=10000000,
                                           dummy4unknown=False)
        pearson, spearman, oov_ratio = results
        spearman_scores.append(spearman[0])
        pearson_scores.append(pearson[0])

    avg_spearman = round(sum(spearman_scores) / len(spearman_scores), 3)
    avg_pearson = round(sum(pearson_scores) / len(pearson_scores), 3)

    #by_spear[avg_spearman].append(p)
    #by_pear[avg_pearson].append(p)
    #all_ =  {**p, **pmi_p}
    #logline = '\t'.join(['%s=%s' % (k, str(v)) for k, v in sorted(all_.items())])
    logline = f'dim={dim}\tepoch={epochs}\tmincount={mincount}\twindow={window}'
    line = str(round((avg_spearman+avg_pearson)/2, 3)) + '\t' + str(avg_spearman) + '\t' + str(avg_pearson) + '\t' + logline
    print(str(TESTRUN).zfill(2) + ': ' + line[0:60] + '...')
    TESTRUN += 1
    overall_average.append(avg_spearman)
    """ Write logfile """
    with open('diff1.txt', 'a') as f:
        f.write(line + '\n')

dimensions_ = [100]
windows_ = [2,2,2,2,2]
min_count_ = [1]
epochs_ = [7]

for dim in dimensions_:
    for win in windows_:
        for minc in min_count_:
            for e in epochs_:
                model = Word2Vec(vector_size=dim, sg=1, window=win, min_count=minc, sentences=texts, epochs=e)
                model.wv.save_word2vec_format('ft.test', binary=False)
                #model = KeyedVectors.load_word2vec_format('fasttext.test', encoding='utf8')
                evaluate_model(datasets, dim, e, win, minc)

print(sum(overall_average)/len(overall_average))
